The source code is provided in text format.

The source code was compiled and run in Delphi version 7. 

Should you wish to have a copy of the source code in Pascal format, please don't hesitate to contact me at dejager4@gmail.com.

The source code is provided under the same license as the binary (GPL-3.0).